
/**
 *
 * Nombre de clase: Cargo
 *
 * esto define cuales pueden ser los cargos de los candidatos
 *
 *
 * @version: 28/10/2021/A
 *
 * @autores: Caraballo Ian, Craco Ivan, Serantes Matias
 *
 */

/**
 * Diputado o Senador
 */
public enum Cargo {
    DIPUTADO,
    SENADOR
}
